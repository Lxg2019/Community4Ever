﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DB.Models.Persons
{
    public enum ContactType
    {
        WeChat,
        Google,
        Facebook,
        Instagram,
        Twitter,
        Email,
        Tel
    }
}
