using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DB.Models.Roles
{
    public class Role
    {
        public int Id { get; set; }

        public string Name { get; set; } // administrator, user, prodiver, taker, driver,

    }
}
