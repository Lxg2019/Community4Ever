﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using DB.Models.Persons;

namespace DB.Models
{
    public class C4EContext : DbContext
    {
        public C4EContext(DbContextOptions<C4EContext> options)
            :base(options)
        {
            
        }

        public DbSet<Person> Person { get; set; }
    }
}
