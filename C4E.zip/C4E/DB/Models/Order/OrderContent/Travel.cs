﻿using DB.Models.Address;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DB.Models.Order.OrderOfContent
{
    public class Travel
    {
        public DateTime End { get; set; }

        public virtual OrderPlace Orderplace{ get; set; }

        public string OrderDetails { get; set; }
    }
}
