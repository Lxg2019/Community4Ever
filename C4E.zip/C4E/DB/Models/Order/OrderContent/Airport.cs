using DB.Models.Address;
using DB.Models.Vehicles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DB.Models.Order.OrderOfContent
{
    public class Airport:OrderContent
    {

        public Adress FromAdress { get; set; }

        public Adress ToAdress { get; set; }

        public virtual Vehicle Vehcile { get; set; }

        public int AmountofPackage { get; set; }


    }
}
