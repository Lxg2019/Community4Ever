﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DB.Models.Order
{
    public class OrderStatus
    {
        public int Id { get; set; }

        public Status MyProperty { get; set; }
    }
}
